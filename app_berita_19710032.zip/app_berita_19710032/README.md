# Ahmad Norifansyah (19710109)
## Screenshots :

- Splash Screen
![](Ssimg/Screenshot1.png)

- Home Screen 
![](Ssimg/Screenshot2.png)