package com.example.app_berita_19710109

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
